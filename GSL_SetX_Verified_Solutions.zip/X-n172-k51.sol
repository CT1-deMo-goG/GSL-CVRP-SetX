# [GSL ENGINE - MASTER OPTIMIZATION]
# MODULE: GSL_CVRP_V22 (BENCHMARK)
# INSTANCE: X-n172-k51
# ----------------------------------------
Route #1: 77 169 136
Route #2: 144 165
Route #3: 125 162
Route #4: 2 71
Route #5: 28 167
Route #6: 90 95
Route #7: 3 166
Route #8: 115 150
Route #9: 26 139
Route #10: 45 72 44 30 66 73
Route #11: 35 129
Route #12: 74 109
Route #13: 106 16 32 41
Route #14: 46 133
Route #15: 55 76 54
Route #16: 24 52
Route #17: 25 60
Route #18: 49 86 120
Route #19: 21 83
Route #20: 47 157
Route #21: 51 67 146 145
Route #22: 27 111
Route #23: 12 34
Route #24: 84 85
Route #25: 88 102
Route #26: 100 113
Route #27: 36 163
Route #28: 94 96 89 98 93 158
Route #29: 6 43 15 151 42
Route #30: 79 56 31 39 78 10 23
Route #31: 14 20 57
Route #32: 48 69 159
Route #33: 131 70 114 110 92
Route #34: 80 101 147
Route #35: 7 127 105 119 103 62
Route #36: 137 168
Route #37: 134 40
Route #38: 124 75
Route #39: 156 154 17 135 1 140 170
Route #40: 58 97
Route #41: 116 138 61
Route #42: 108 164 99 142 37 107 149 155 87
Route #43: 153 130
Route #44: 128 5 9 29 8 64 81
Route #45: 22 18 112 132 161 11 53
Route #46: 38 63 104
Route #47: 171 68 152 121 122 91
Route #48: 117 118
Route #49: 50 160 65
Route #50: 123 141 13
Route #51: 4 33 82 19
Route #52: 59 148
Route #53: 143 126
# ----------------------------------------
RESULT_COST: 50243.70
BKS_TARGET: 45607.00
GSL_BKS_GAP: +10.17%
VEHICLES_USED: 53/51
PROCESS_TIME: 0.3213s
STATUS: FEASIBLE (+2)
