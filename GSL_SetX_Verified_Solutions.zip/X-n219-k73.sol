# [GSL ENGINE - MASTER OPTIMIZATION]
# MODULE: GSL_CVRP_V22 (BENCHMARK)
# INSTANCE: X-n219-k73
# ----------------------------------------
Route #1: 97 1 208
Route #2: 93 3 112
Route #3: 180 4 191
Route #4: 138 5 176
Route #5: 202 6 206
Route #6: 7 92 168
Route #7: 44 8 215
Route #8: 9 131 183
Route #9: 10 82 98
Route #10: 11 14 80
Route #11: 12 20 41
Route #12: 56 218 13
Route #13: 57 15 22
Route #14: 115 164 16
Route #15: 17 104 118
Route #16: 18 78 178
Route #17: 195 199 19
Route #18: 119 21 203
Route #19: 23 29 174
Route #20: 24 49 117
Route #21: 70 25 128
Route #22: 179 189 26
Route #23: 122 27 149
Route #24: 182 28 100
Route #25: 146 173 30
Route #26: 157 32 39
Route #27: 130 133 34
Route #28: 35 60 140
Route #29: 88 36 76
Route #30: 38 40 150
Route #31: 187 42 63
Route #32: 45 111 129
Route #33: 46 66 75
Route #34: 47 123 170
Route #35: 89 91 48
Route #36: 103 143 50
Route #37: 51 64 127
Route #38: 61 52 95
Route #39: 102 217 53
Route #40: 54 151 216
Route #41: 55 86 197
Route #42: 2 72 58
Route #43: 132 62 108
Route #44: 65 144 154
Route #45: 204 67 106
Route #46: 126 68 105
Route #47: 212 69 136
Route #48: 73 184 213
Route #49: 74 137 205
Route #50: 141 77 177
Route #51: 90 214 81
Route #52: 155 181 83
Route #53: 84 113 160
Route #54: 85 162 188
Route #55: 87 124 193
Route #56: 145 186 94
Route #57: 31 152 96
Route #58: 99 207 210
Route #59: 142 163 101
Route #60: 107 109 114
Route #61: 192 110 167
Route #62: 71 190 116
Route #63: 194 120 196
Route #64: 79 135 121
Route #65: 125 139 147
Route #66: 33 200 148
Route #67: 153 165 172
Route #68: 171 156 209
Route #69: 59 198 158
Route #70: 37 175 159
Route #71: 43 169 161
Route #72: 166 185
Route #73: 134 211 201
# ----------------------------------------
RESULT_COST: 118368.80
BKS_TARGET: 117595.00
GSL_BKS_GAP: +0.66%
VEHICLES_USED: 73/73
PROCESS_TIME: 0.2187s
STATUS: FEASIBLE
