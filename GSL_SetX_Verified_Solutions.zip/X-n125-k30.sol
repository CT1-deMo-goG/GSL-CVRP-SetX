# [GSL ENGINE - MASTER OPTIMIZATION]
# MODULE: GSL_CVRP_V22 (BENCHMARK)
# INSTANCE: X-n125-k30
# ----------------------------------------
Route #1: 26 24
Route #2: 86 96
Route #3: 3 60
Route #4: 38 106
Route #5: 61 83 76
Route #6: 82 56
Route #7: 18 21
Route #8: 121 57 100
Route #9: 53 98 119
Route #10: 93 111
Route #11: 12 103
Route #12: 42 81 92 15 17 116 66
Route #13: 35 113 108
Route #14: 102 52 44 123 97 13
Route #15: 23 49 14 31
Route #16: 33 37 62
Route #17: 48 5 32
Route #18: 8 39 101 20
Route #19: 87 114 11 19 9 59
Route #20: 74 16 99 110
Route #21: 25 109 36 79 63 46 1 55 117
Route #22: 94 47 68 27 30 85
Route #23: 90 43 73 122
Route #24: 45 71 104 84
Route #25: 75 120
Route #26: 10 69 29
Route #27: 70 115 88 89 105 51
Route #28: 78 28 124 2 6 34 50
Route #29: 95 107 41 67 72 54
Route #30: 118 22 40 65 80 58 4 7 77 64
Route #31: 112 91
# ----------------------------------------
RESULT_COST: 57917.63
BKS_TARGET: 55539.00
GSL_BKS_GAP: +4.28%
VEHICLES_USED: 31/30
PROCESS_TIME: 0.1858s
STATUS: FEASIBLE (+1)
