# [GSL ENGINE - MASTER OPTIMIZATION]
# MODULE: GSL_CVRP_V22 (BENCHMARK)
# INSTANCE: X-n148-k46
# ----------------------------------------
Route #1: 54 10 14 76
Route #2: 28 51 68
Route #3: 46 89
Route #4: 72 93
Route #5: 1 59
Route #6: 26 130
Route #7: 87 143 43
Route #8: 41 78 45
Route #9: 137 82 136
Route #10: 84 122
Route #11: 110 85 134
Route #12: 80 119 103
Route #13: 106 129
Route #14: 107 118
Route #15: 121 140
Route #16: 17 112 2
Route #17: 3 12 117
Route #18: 100 115 135 8
Route #19: 18 88
Route #20: 21 58
Route #21: 25 29 63 24 11
Route #22: 4 114 53 126
Route #23: 124 56 83
Route #24: 97 132
Route #25: 42 99 23
Route #26: 5 71 86
Route #27: 52 101 48 6 125 37
Route #28: 67 61 7 57
Route #29: 69 38 9 50
Route #30: 15 90 116
Route #31: 16 74 108
Route #32: 19 64 94 138 31
Route #33: 98 81 120 20
Route #34: 22 55 27
Route #35: 32 113
Route #36: 34 139
Route #37: 104 70 35 142
Route #38: 30 60 39
Route #39: 40 105
Route #40: 44 75
Route #41: 47 73
Route #42: 49 145 66 13 36 33 96
Route #43: 127 77 109 62
Route #44: 141 147 65
Route #45: 79 91 128
Route #46: 133 144 131 102
Route #47: 111 123 146 92
Route #48: 95
# ----------------------------------------
RESULT_COST: 46164.22
BKS_TARGET: 43448.00
GSL_BKS_GAP: +6.25%
VEHICLES_USED: 48/46
PROCESS_TIME: 0.1447s
STATUS: FEASIBLE (+2)
