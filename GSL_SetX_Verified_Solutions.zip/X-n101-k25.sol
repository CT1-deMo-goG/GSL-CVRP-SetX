# [GSL ENGINE - MASTER OPTIMIZATION]
# MODULE: GSL_CVRP_V22 (BENCHMARK)
# INSTANCE: X-n101-k25
# ----------------------------------------
Route #1: 28 42 78 68
Route #2: 75 93 14
Route #3: 10 25 1
Route #4: 23 61 21 39
Route #5: 12 8
Route #6: 56 94 3
Route #7: 79 11 85 30
Route #8: 77 67 88
Route #9: 15 70 86
Route #10: 22 41 20
Route #11: 65 49 6 37 57
Route #12: 81 51 83
Route #13: 66 84 90 13
Route #14: 35 46 31
Route #15: 4 18 50
Route #16: 27 97 19
Route #17: 100 52 91
Route #18: 38 47 26 48 96 34
Route #19: 32 33 53 73 95 24
Route #20: 17 80 5
Route #21: 92 9 55
Route #22: 64 72 87 36 29 43 45 2 7
Route #23: 89 98 99 62 71
Route #24: 76 16 69 74
Route #25: 58 63 40 44
Route #26: 59 60 82
Route #27: 54
# ----------------------------------------
RESULT_COST: 31409.38
BKS_TARGET: 27591.00
GSL_BKS_GAP: +13.84%
VEHICLES_USED: 27/25
PROCESS_TIME: 0.0770s
STATUS: FEASIBLE (+2)
